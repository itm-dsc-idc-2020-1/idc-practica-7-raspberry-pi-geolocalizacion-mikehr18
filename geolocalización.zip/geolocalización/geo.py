import random
import mysql.connector

db = mysql.connector.connect(
    host ="172.20.10.4",#ip del servidor que va a dibujar el mapa
    user ="root",
    passwd="",
    database="php_mi_mapa"
)




x1=197218046
x2=197218990

y1=1011856763
y2=1011858945

latitud=random.randrange(x1,x2)/10000000
longitud= random.randrange(y1,y2)/10000000*-1
print(latitud)
print(longitud)

cursor= db.cursor()

sql = "INSERT INTO `lugares` VALUES (%s, %d, %d, %s, %s)"
val = ("edificio O", 1, 1,str(latitud),str(longitud))
cursor.execute(sql,val)
db.commit()



