--
-- php_mi_mapa.sql
--
-- Crear un mapa con coordenadas almacenadas en MySQL
-- Rogelio Ferreira Escutia - mayo 2017

create database php_mi_mapa;
use php_mi_mapa;
create table lugares (nombre text, id int, numero int, latitud text, longitud text);

-- Coordenadas del Edificio "I" del Departamento de Sistemas y Computación del ITM


insert into lugares values("Edificio O", 1, 1, "19.721878", "-101.185852");
insert into lugares values("Edificio O", 1, 1, "19.721784", "-101.185761");
insert into lugares values("Edificio O", 1, 1, "19.721860", "-101.185753");
insert into lugares values("Edificio O", 1, 1, "19.721803", "-101.185869");