function dibujar(latitud1, longitud1, latitud2, longitud2,latitud3, longitud3, latitud4, longitud4,){
    var canvas=document.getElementById('mapa');
	if(canvas&&canvas.getContext){
		var ctx=canvas.getContext("2d");
		if (ctx) {
            
            //Conversion de datos que se reciben
            a=parseFloat(latitud1);
            b=parseFloat(longitud1);
            c=parseFloat(latitud2);
            d=parseFloat(longitud2);

            a1=parseFloat(latitud3);
            b1=parseFloat(longitud3);
            c1=parseFloat(latitud4);
            d1=parseFloat(longitud4);

            document.write("<br />Recibiendo: "+a+" "+b+" "+c+" "+d+" ");
            
            // Regla de 3 para calcular el primer punto
            latitud_superior = 19.723225;
            y1 = ((latitud_superior - a)*500)/0.01108;
            longitud_superior = -101.185929;
            x1 = ((longitud_superior - b)*1000)/(-0.001597);
            document.write("<br />x1: "+x1+" y1: "+y1);
            
           
            
            // Regla de 3 para calcular el segundo punto
            y2 = ((latitud_superior - c)*500)/0.01108;
            x2 = ((longitud_superior - d)*1000)/(-0.001597);
            document.write("<br />x2: "+x2+" y2: "+y2);
            
        
            

            ctx.strokeRect(y1,x1,y2,x2);

            
		} else { alert("Error al crear el contexto"); }
    } 
    
    

}